# from os import name, read
import pathlib
import csv
import os
import json

def log_data(user, action):
    with open(pathlib.Path(__file__).parent.joinpath('LOG').joinpath('ATM_LOG.json'), 'a') as json_file:
        temp_dikt = {user: action}
        json_file.write(json.dumps(temp_dikt))

def sell_many(user_id, many):
    # деньги для банкомата
    n1000 = 2
    n500 = 4
    n200 = 8 
    n100 = 12

    def sell(user_id,k1, k05, k02, k01):
        temp_many = 0
        temp = (1000*k1)+(500*k05)+(200*k02)+(100*k01)


        with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'r') as many_file_temp:
                temp_many = int(many_file_temp.read())
        
        with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'w') as many_file: 
            many_file.write(str(temp_many-temp))
            log_data(user_id, f'sell {temp}, summ {temp_many}')


    for k1000 in range(min(many// 1000, n1000), -1, -1):
        for k500 in range(min(many // 500, n500), -1, -1):
            for k200 in range(min(many // 200, n200), -1, -1):
                for k100 in range(min(many // 100, n100), -1, -1):
                    if 1000 * k1000 + 500 * k500 + 200 * k200 + 100 * k100 == many:
                        sell(user_id, k1000, k500, k200, k100)
                        return (k1000, k500, k200, k100)

def cln():
    os.system('cls||clear')

def balance_add(user_id): #prod
    cln()
    temp_many = int(balance_checkr(user_id))
    

    temp = int(input('n mach ? '))
    log_data(user_id, f'add {temp}, summ {temp_many}')
    with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'w') as many_file:
        many_file.write(str(int(temp_many)+temp))
         
def balance_checkr(user_id):    #prod
    cln()
    temp_many = None
    
    with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'r') as many_file_temp:
            temp_many = many_file_temp.read()
    if  temp_many == '':
        with open(pathlib.Path(__file__).parent.joinpath('DEPOSIT').joinpath(f'{user_id}.txt'), 'w') as many_file_temp:
                many_file_temp.write('0')
    return temp_many

def user_menu(menu_page):
    if menu_page == '1':
        print('____________________')
        print('проверить баланс 1 ')
        print('внести деньги 2 ')
        print('выход 3 ')
        print('снять деньги  4 ')
        print('--------------------')
    # if menu_page == '2'
    return

def validator(user_name = 0,user_password = 0): #prod
    with open(pathlib.Path(__file__).parent.joinpath('db').joinpath('db.txt'), 'r') as validator_file:
        #print(validator_file.read())
        temp_file = csv.DictReader(validator_file)
        for dict_user in temp_file:
            if user_name == dict_user['name']:
                if user_password == dict_user['password']:
                    return dict_user['name']
                else:
                    print('error password')
            else:
                print('user is not found... ')
                return None

def user_akaunt(user_name,user_password):
    while True:
        flag = validator(user_name,user_password)
        if flag != None:
            user_menu('1')
            user_option = input('_ ')
            if user_option == '1':
                log_data(user_name, 'loock')
                print(f'you deposut {str(balance_checkr(user_name))} $')

            elif user_option == '2':
                balance_add(user_name)
            elif user_option == '3':
                log_data(user_name, 'exit')
                cln()
                break
            elif user_option == '4':
                a = int(input('сколько снять '))
                if int(balance_checkr(user_name)) > int(a):
                    temp_sell_user = sell_many(user_name, a)
                    print(f' 1000 $ = {temp_sell_user[0]},  500 $ = {temp_sell_user[1]},  200 $ = {temp_sell_user[2]},  100 $ = {temp_sell_user[3]}')
                else:
                    print(f'немє стільки коштів ваш баланс {balance_checkr(user_name)}')
        else:
            break

# user_akaunt('user_1','1111')
    print('out')

def start():
    for i in range(3):
        
        user_akaunt(input('Логин '),input(' Пароль '))

start()

    
